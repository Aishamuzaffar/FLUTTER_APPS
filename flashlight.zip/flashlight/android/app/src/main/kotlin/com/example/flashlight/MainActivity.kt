package com.example.flashlight

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
