import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:torch_compat/torch_compat.dart';

void main() {
  runApp(FlashlightApp());
}

class FlashlightApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flashlight App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: FlashlightScreen(),
    );
  }
}

class FlashlightScreen extends StatefulWidget {
  @override
  _FlashlightScreenState createState() => _FlashlightScreenState();
}

class _FlashlightScreenState extends State<FlashlightScreen> {
  bool _isFlashOn = false;

  @override
  void initState() {
    super.initState();
    _initFlashlight();
  }

  void _initFlashlight() async {
    if (await Permission.camera.request().isGranted) {
      // Permission already granted, enable flashlight
      _turnFlashlightOn();
    } else {
      // Permission not granted, request it from the user
      await Permission.camera.request();
      if (await Permission.camera.isGranted) {
        _turnFlashlightOn();
      }
    }
  }

  void _toggleFlashlight() {
    setState(() {
      _isFlashOn = !_isFlashOn;
      if (_isFlashOn) {
        TorchCompat.turnOn();
      } else {
        TorchCompat.turnOff();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flashlight'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF2C5364),
              Color(0xFF0F2027),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Icon(
                _isFlashOn ? Icons.flash_on : Icons.flash_off,
                size: 100.0,
                color: _isFlashOn ? Colors.yellow : Colors.white,
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _toggleFlashlight,
                style: ElevatedButton.styleFrom(
                  primary: _isFlashOn ? Colors.red : Colors.green,
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                child: Text(
                  _isFlashOn ? 'Turn Off' : 'Turn On',
                  style: TextStyle(fontSize: 20),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
