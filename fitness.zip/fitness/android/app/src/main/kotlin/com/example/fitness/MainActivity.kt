package com.example.fitness

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
